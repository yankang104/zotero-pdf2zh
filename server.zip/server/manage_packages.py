#!/usr/bin/env python3
"""Inspect and maintain Zotero PDF2zh translation environments.

`status`, `doctor`, and `network` are read-only. `update` installs packages in the current
uv/conda environment, same as update_packages.py.

The normal/default mode is auto: keep an existing uv/conda environment;
for a fresh install prefer uv. A failed install never silently switches managers.
"""

from __future__ import annotations

import argparse

from packaging.specifiers import SpecifierSet
from pdf2zh_server.environment.discovery import (
    ENGINE_ENV_NAMES,
    PRIMARY_PACKAGES,
    find_existing_environment,
    format_versions,
    read_versions,
)
from pdf2zh_server.environment.install import (
    managed_runtime_health,
    transactional_install_or_update,
)
from pdf2zh_server.environment.network import (
    print_probe_report,
    probe_indexes,
    usable_indexes,
)
from pdf2zh_server.environment.updates import server_version_from_source


def _engines(value: str) -> list[str]:
    return list(ENGINE_ENV_NAMES) if value == "all" else [value]


def status(engine: str, env_tool: str) -> bool:
    existing = find_existing_environment(engine, env_tool)
    if not existing:
        print(f"\n[{engine}] 未找到现有翻译环境 (env_tool={env_tool})。")
        return False
    tool, env_dir, python_path = existing
    try:
        versions = read_versions(python_path, engine)
    except Exception as exc:
        print(f"\n[{engine}] 无法读取版本: {exc}")
        return False
    print(f"\n[{engine}] env_tool={tool}")
    print(f"环境: {env_dir}")
    print(f"Python: {python_path}")
    for name, version in versions.items():
        print(f"  {name:14s} {version or 'NOT INSTALLED'}")
    return True


def doctor(engine: str, env_tool: str) -> bool:
    """Read-only diagnosis of managed env candidates; never modifies packages."""
    print(f"\nServer: {server_version_from_source()}")
    tools = ("uv", "conda") if env_tool == "auto" else (env_tool,)
    candidates = []
    seen_pythons = set()
    for selected_tool in tools:
        existing = find_existing_environment(engine, selected_tool)
        if existing and str(existing[2]) not in seen_pythons:
            seen_pythons.add(str(existing[2]))
            candidates.append(existing)
    if not candidates:
        print(f"[{engine}] 未找到 {env_tool} 翻译环境。")
        return False

    if len(candidates) > 1:
        print(
            "⚠️ 检测到多个环境；将分别检查。实际运行环境以 Server 翻译命令中的路径为准。"
        )

    all_healthy = True
    for tool, env_dir, python_path in candidates:
        print(f"\n[{engine}] env_tool={tool}")
        print(f"环境: {env_dir}")
        print(f"Python: {python_path}")
        try:
            versions = read_versions(python_path, engine)
        except Exception as exc:
            print(f"❌ 读取翻译环境版本失败: {exc}")
            all_healthy = False
            continue
        for name, version in versions.items():
            print(f"  {name:14s} {version or 'NOT INSTALLED'}")

        compatible = True
        if engine == "pdf2zh_next":
            version = versions.get("bitstring")
            compatible = bool(version and SpecifierSet(">=4.3.0,<5").contains(version))
            if compatible:
                print(f"✅ bitstring {version} 满足 >=4.3.0,<5")
            else:
                print(f"❌ bitstring {version or '未安装'} 不满足 >=4.3.0,<5")

        healthy, reason = managed_runtime_health(engine, python_path)
        if healthy:
            if engine == "pdf2zh_next":
                print("✅ 运行时依赖检查通过（包括 bitstring.BitStream 导入与构造）")
            else:
                print(f"✅ {engine} 依赖检查通过")
        else:
            print(f"❌ 运行时依赖检查失败: {reason}")

        if not (compatible and healthy):
            print("建议先确认 Server 已更新，再在 server 目录运行:")
            print(f"  python update_packages.py --engine {engine} --env-tool {tool}")
            all_healthy = False
    return all_healthy


def network(engine: str, index_url: str | None, timeout: float) -> bool:
    results = probe_indexes(
        PRIMARY_PACKAGES[engine],
        preferred_index=index_url,
        timeout=timeout,
    )
    print(f"\n[{engine}] target={PRIMARY_PACKAGES[engine]}")
    print_probe_report(results)
    return bool(usable_indexes(results))


def update(
    engine: str,
    env_tool: str,
    index_url: str | None,
    timeout: float,
    assume_yes: bool,
) -> bool:
    existing = find_existing_environment(engine, env_tool)
    if existing:
        try:
            before = read_versions(existing[2], engine)
            print(f"\n[{engine}] 当前: {format_versions(before)}")
        except Exception:
            pass
    else:
        print(f"\n[{engine}] 未找到 {env_tool} 环境，将按首次安装流程创建。")

    if not assume_yes:
        print("更新会在当前翻译环境中直接安装依赖，不再创建 staging 或 backup 环境。\n")
        try:
            answer = input("确认开始安全更新？(y/N): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        if answer not in {"y", "yes"}:
            print("已取消更新。")
            return True

    success, _, _ = transactional_install_or_update(
        engine,
        env_tool=env_tool,
        preferred_index=index_url,
        network_timeout=timeout,
        require_deepseek_thinking=(engine == "pdf2zh_next"),
    )
    return success


def main() -> int:
    parser = argparse.ArgumentParser(
        description="检查网络、查看版本或安全更新 Zotero PDF2zh 翻译环境。"
    )
    parser.add_argument("action", choices=["network", "status", "doctor", "update"])
    parser.add_argument(
        "--engine",
        choices=["pdf2zh_next", "wenyi", "all"],
        default="pdf2zh_next",
    )
    parser.add_argument(
        "--env-tool",
        choices=["auto", "uv", "conda"],
        default="auto",
        help=(
            "默认 auto：沿用已有 uv/conda 环境；没有已有环境时优先 uv。"
            "显式指定 uv 或 conda 时严格使用所选工具，安装失败不会静默切换。"
        ),
    )
    parser.add_argument("--index-url", default=None)
    parser.add_argument("--network-timeout", type=float, default=4.0)
    parser.add_argument(
        "--yes",
        action="store_true",
        help="跳过 manage_packages.py 自己的确认。",
    )
    args = parser.parse_args()

    ok = True
    for engine in _engines(args.engine):
        if args.action == "status":
            result = status(engine, args.env_tool)
        elif args.action == "doctor":
            result = doctor(engine, args.env_tool)
        elif args.action == "network":
            result = network(engine, args.index_url, args.network_timeout)
        else:
            result = update(
                engine,
                args.env_tool,
                args.index_url,
                args.network_timeout,
                args.yes,
            )
        ok = ok and result

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
